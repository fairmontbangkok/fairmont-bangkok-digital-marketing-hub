# Fairmont Bangkok Sukhumvit — Auto-Refresh Setup Guide

The dashboard refreshes automatically every day at **8:00 AM Bangkok time** via GitHub Actions.

---

## How it works

```
Every day at 8am BKK
       ↓
GitHub Actions wakes up
       ↓
Python script calls Supermetrics API
(Google Ads + Facebook Ads data)
       ↓
Injects fresh numbers into index.html
       ↓
Commits updated file to repo
       ↓
GitHub Pages redeploys automatically
       ↓
Your live URL shows today's data ✓
```

---

## One-time setup (15 minutes)

### Step 1 — Get your Supermetrics API key

1. Go to [supermetrics.com](https://supermetrics.com) → log in
2. Go to **Settings → API** (or **Hub → API keys**)
3. Copy your API key

### Step 2 — Get your ad account IDs

**Google Ads account ID:**
1. Log into [ads.google.com](https://ads.google.com)
2. Your account ID is the number in the top right (format: `123-456-7890`)
3. Remove dashes: `1234567890`

**Facebook Ads account ID:**
1. Log into [business.facebook.com](https://business.facebook.com)
2. Go to Ad Accounts → your account ID starts with `act_`
3. Copy the full ID including `act_` prefix

### Step 3 — Add secrets to GitHub

1. Go to your GitHub repo: `fairmontbangkok/fairmont-seo-dashboard`
2. Click **Settings** → **Secrets and variables** → **Actions**
3. Click **New repository secret** and add these three:

| Secret name | Value |
|---|---|
| `SUPERMETRICS_API_KEY` | Your Supermetrics API key |
| `GOOGLE_ADS_ACCOUNT` | Your Google Ads account ID (digits only) |
| `FACEBOOK_ADS_ACCOUNT` | Your Facebook Ads account ID (e.g. `act_123456789`) |

### Step 4 — Add the workflow files to your repo

Upload these files to your GitHub repo (same way you uploaded `index.html`):

```
.github/
  workflows/
    daily-refresh.yml    ← the scheduler
scripts/
  fetch_and_build.py     ← the data fetcher
data.json                ← auto-created on first run
```

### Step 5 — Test it manually

1. Go to your repo → **Actions** tab
2. Click **Daily SEO Dashboard Refresh**
3. Click **Run workflow** → **Run workflow**
4. Watch the logs — should complete in ~30 seconds
5. Check your live URL — top bar will show live Google Ads spend data

---

## What data updates automatically

| Data | Source | Frequency |
|---|---|---|
| Google Ads spend, clicks, impressions, CTR | Supermetrics → Google Ads | Daily 8am |
| Facebook Ads spend, clicks, impressions | Supermetrics → Facebook Ads | Daily 8am |
| Dashboard timestamp | Auto | Daily 8am |

## What you still update manually (every Monday)

| Data | How |
|---|---|
| Keyword positions | Manual SERP check → tell Claude → paste new index.html |
| Audit scores (title tag, schema, speed) | Run checks → tell Claude |
| Action plan tasks | Tick checkboxes on dashboard directly |
| LLM visibility score | Manual prompt testing → tell Claude |

---

## Troubleshooting

**Workflow fails with "authentication error"**
→ Check your secrets are set correctly in GitHub → Settings → Secrets

**No data appears / shows zeros**
→ The script falls back gracefully — dashboard still loads, just without live ad data
→ Check the Actions log for the specific error message

**Want to trigger a refresh right now?**
→ Go to Actions → Daily SEO Dashboard Refresh → Run workflow

---

## Adding more data sources later

The script (`scripts/fetch_and_build.py`) is easy to extend. To add Google Search Console:
1. Connect it in Supermetrics (ds_id = `GW`)
2. Add a `fetch_search_console()` function in the script
3. This would give you real keyword position data daily

---

*Fairmont Bangkok Sukhumvit · Thailand's first Fairmont · 10 Sukhumvit Soi 20, Bangkok*
